// ==UserScript==
// @name            Redirect YouTube to Piped
// @version         1.0.0
// @description     Redirect YouTube to Invidious, Piped
// @author          nitrohorse (https://nitrohorse.com/)
// @namespace       https://gitlab.com/-/snippets/2360489
// @grant           none
// @match           https://*.youtube.com/*
// @match           https://*.youtu.be/*
// @run-at          document-start
// ==/UserScript==

(function iife(inject) {
	'use strict';

	// Trick to get around the sandbox restrictions in Greasemonkey (Firefox)
	// Inject code into the main window if criteria match
	if (this !== window && inject) {
		window.eval('(' + iife.toString() + ')();');
		return;
	}

	top.location.hostname = "piped.video";
})(true);
