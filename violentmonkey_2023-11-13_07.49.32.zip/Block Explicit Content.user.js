// ==UserScript==
// @name         Block Explicit Content
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Block explicit content based on keywords and URLs
// @author       You
// @license MIT
// @match        *://*/*
// @grant        none
// @run-at          document-start
// ==/UserScript==

(function() {
    const bannedKeywords = [
        "sex", "jav", "hentai", "xxx", "porn", "pussy", "ass", "butt", "tits", "boobs", "ntr", "ecchi", "kidmo", "vlxx",
        "adult", "nude", "naked", "erotic", "explicit", "mature", "hardcore", "milf", "busty", "bdsm", "fetish", "blowjob",
        // Add more explicit keywords here
    ];
    const bannedSites = [
        "xvideos.com", "xnxx.com", "pornhub.com", "youporn.com", "redtube.com", "tube8.com",
        // Add more explicit sites here
    ];

    const currentUrl = window.location.href;

    if (bannedKeywords.some(keyword => currentUrl.includes(keyword)) || bannedSites.some(site => currentUrl.includes(site))) {
        window.location.replace("http://stackoverflow.com");
    }
})();
